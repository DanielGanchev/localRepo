package craftsmanLab;

import craftsmanLab.core.CraftsmanLabImpl;
import craftsmanLab.models.ApartmentRenovation;
import craftsmanLab.models.Craftsman;

import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {


    }
}
