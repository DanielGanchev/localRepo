package craftsmanLab.core;

import craftsmanLab.models.ApartmentRenovation;
import craftsmanLab.models.Craftsman;

import java.util.*;

public class CraftsmanLabImpl implements CraftsmanLab {

    private final Queue<ApartmentRenovation> apartmentRenovations;
    private final Queue<Craftsman> craftsmen;
    private final Map<String,String> craftsmanJobs;
    private final Map<String,Double> craftsmanProfits;
    private final Queue<String> adresses;
    private final Queue<Craftsman> offeredJob;

    public CraftsmanLabImpl() {
        this.apartmentRenovations= new PriorityQueue<>();
        this.craftsmen = new PriorityQueue<>();
        this.craftsmanJobs = new HashMap<>();
        this.craftsmanProfits = new HashMap<>();
        this.adresses = new PriorityQueue<>();
        this.offeredJob = new PriorityQueue<>();
    }


    @Override
    public void addApartment(ApartmentRenovation job) {
       if (adresses.contains(job.address)) {
           throw new IllegalArgumentException();
       }
        this.apartmentRenovations.offer(job);
       this.craftsmanJobs.put(job.address,null);


    }

    @Override
    public void addCraftsman(Craftsman craftsman) {
        if (this.craftsmen.contains(craftsman)){
            throw new IllegalArgumentException();
        }
        this.craftsmen.offer(craftsman);
        this.craftsmanProfits.put(craftsman.name,craftsman.totalEarnings);


    }

    @Override
    public boolean exists(ApartmentRenovation job) {
        Queue<ApartmentRenovation> temp = new PriorityQueue<>();
        boolean exists = false;
        while (!this.apartmentRenovations.peek() .equals(job) && !this.apartmentRenovations.isEmpty()){
            ApartmentRenovation current = this.apartmentRenovations.poll();

            temp.offer(current);
        }
        if (this.apartmentRenovations.peek().equals(job)){
            exists = true;
        }
        while (!temp.isEmpty()){
            ApartmentRenovation current = temp.poll();
            this.apartmentRenovations.offer(current);
        }
        return exists;
    }

    @Override
    public boolean exists(Craftsman craftsman) {
        Queue<Craftsman> temp = new PriorityQueue<>();
        boolean exists = false;
        while (!this.craftsmen.peek().equals(craftsman) && !this.craftsmen.isEmpty()){
            Craftsman current = this.craftsmen.poll();
            temp.offer(current);
        }
        if (this.craftsmen.peek().equals(craftsman)){
            exists = true;
        }
        while (!temp.isEmpty()){
            Craftsman current = temp.poll();
            this.craftsmen.offer(current);
        }
        return exists;

    }

    @Override
    public void removeCraftsman(Craftsman craftsman) {
        if (!exists(craftsman) && offeredJob.contains(craftsman)){
            throw new IllegalArgumentException();
        }
        this.craftsmen.remove(craftsman);
        this.craftsmanProfits.remove(craftsman.name);
        this.craftsmanJobs.remove(craftsman.name);





    }

    @Override
    public Collection<Craftsman> getAllCraftsmen() {
        return this.craftsmen;
    }

    @Override
    public void assignRenovations() {

    }

    @Override
    public Craftsman getContractor(ApartmentRenovation job) {
        if (!exists(job)){
            throw new IllegalArgumentException();
        }
        if ()
    }

    @Override
    public Craftsman getLeastProfitable() {
        return null;
    }

    @Override
    public Collection<ApartmentRenovation> getApartmentsByRenovationCost() {
        return null;
    }

    @Override
    public Collection<ApartmentRenovation> getMostUrgentRenovations(int limit) {
        return null;
    }
}
