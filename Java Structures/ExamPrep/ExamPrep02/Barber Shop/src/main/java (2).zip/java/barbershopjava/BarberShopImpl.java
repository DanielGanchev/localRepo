package barbershopjava;

import javax.crypto.MacSpi;
import java.util.*;
import java.util.stream.Collectors;

public class BarberShopImpl implements BarberShop {


    List<String> barbNames;
    List<Client> clients;
    List<String> clientNames;

    Map<Barber, List<Client>> barbers;

    public BarberShopImpl() {

        this.clients = new ArrayList<>();
        this.barbNames = new ArrayList<>();
        this.clientNames = new ArrayList<>();
        this.barbers = new LinkedHashMap<>();
    }

    @Override
    public void addBarber(Barber b) {
        if (barbNames.contains(b.name)) {
            throw new IllegalArgumentException();
        }


        this.barbNames.add(b.name);
        this.barbers.put(b, new ArrayList<>());


    }

    @Override
    public void addClient(Client c) {
        if (clientNames.contains(c.name)) {
            throw new IllegalArgumentException();
        }

        if (c.barber != null) {
            c.barber = null;
        }

        this.clients.add(c);
        this.clientNames.add(c.name);


    }

    @Override
    public boolean exist(Barber b) {
       return barbNames.contains(b.name);
    }

    @Override
    public boolean exist(Client c) {
        return clientNames.contains(c.name);
    }

    @Override
    public Collection<Barber> getBarbers() {
       return barbers.keySet();
    }

    @Override
    public Collection<Client> getClients() {
        return clients;
    }

    @Override
    public void assignClient(Barber b, Client c) {
        if (!exist(b) || !exist(c)) {
            throw new IllegalArgumentException();
        }


        if (!barbers.get(b).contains(c)) {
            c.barber = b;
            barbers.get(b).add(c);
        }



    }

    @Override
    public void deleteAllClientsFrom(Barber b) {
        if (!exist(b)) {
            throw new IllegalArgumentException();
        }
        barbers.get(b).forEach(c -> c.barber = null);

        barbers.get(b).clear();

    }

    @Override
    public Collection<Client> getClientsWithNoBarber() {
       return clients.stream().filter(c -> c.barber == null).collect(Collectors.toList());
    }

    @Override
    public Collection<Barber> getAllBarbersSortedWithClientsCountDesc() {
        return barbers.entrySet().stream()
                .sorted((b1, b2) -> b2.getValue().size() - b1.getValue().size())
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
    }

    @Override
    public Collection<Barber> getAllBarbersSortedWithStarsDescendingAndHaircutPriceAsc() {
       return barbers.keySet().stream()
               .sorted((b1, b2) -> {
                   if (b1.stars == b2.stars) {
                       return b1.haircutPrice - b2.haircutPrice;
                   }
                   return b2.stars - b1.stars;
               }) .collect(Collectors.toList());

    }

    @Override
    public Collection<Client> getClientsSortedByAgeDescAndBarbersStarsDesc() {
        return clients.stream()
                .sorted((c1, c2) -> {
                    if (c1.age == c2.age) {
                        return c2.barber.stars - c1.barber.stars;
                    }
                    return c2.age - c1.age;
                })
                .collect(Collectors.toList());
    }
}
