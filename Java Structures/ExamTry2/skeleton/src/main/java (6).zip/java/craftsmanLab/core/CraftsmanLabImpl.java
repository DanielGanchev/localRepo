package craftsmanLab.core;

import craftsmanLab.models.ApartmentRenovation;
import craftsmanLab.models.Craftsman;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class CraftsmanLabImpl implements CraftsmanLab {



    private final Map<ApartmentRenovation, Craftsman> assignments = new LinkedHashMap<>();
    private final Map<Craftsman, List<ApartmentRenovation>> craftsmanAll = new HashMap<>();






    @Override
    public void addApartment(ApartmentRenovation job) {
        if (exists(job)) {
            throw new IllegalArgumentException();
        }


        assignments.put(job, null);
    }

    @Override
    public void addCraftsman(Craftsman craftsman) {
        if (exists(craftsman)) {
            throw new IllegalArgumentException();
        }


        craftsmanAll.put(craftsman,new ArrayList<>());


    }

    @Override
    public boolean exists(ApartmentRenovation job) {
      return assignments.containsKey(job);
    }

    @Override
    public boolean exists(Craftsman craftsman) {
        return craftsmanAll.containsKey(craftsman);
    }



    @Override
    public void removeCraftsman(Craftsman craftsman) {
       if (!exists(craftsman) || assignments.containsValue(craftsman)) {
            throw new IllegalArgumentException();
        }
        craftsmanAll.remove(craftsman);


    }

    @Override
    public Collection<Craftsman> getAllCraftsmen() {
        return craftsmanAll.keySet();
    }



    @Override
    public void assignRenovations() {


        PriorityQueue<Craftsman> craftsmanQueue = new PriorityQueue<>(Comparator.comparingDouble(craftsman -> craftsman.totalEarnings));

        craftsmanQueue.addAll(craftsmanAll.keySet());

        for (ApartmentRenovation apartmentRenovation : assignments.keySet()) {
            if (assignments.get(apartmentRenovation) == null && !craftsmanQueue.isEmpty()) {
                Craftsman craftsman = craftsmanQueue.poll();
                assignments.put(apartmentRenovation, craftsman);
                craftsman.totalEarnings += apartmentRenovation.workHoursNeeded * craftsman.hourlyRate;
                craftsmanQueue.add(craftsman);
            }
        }






    }



    @Override
    public Craftsman getContractor(ApartmentRenovation job) {
        Craftsman contractor = assignments.get(job);
        if (contractor == null) {
            throw new IllegalArgumentException();
        }
        return contractor;
    }

    @Override
    public Craftsman getLeastProfitable() {
        if (craftsmanAll.isEmpty()){
            throw new IllegalArgumentException();
        }
        return craftsmanAll.keySet().stream().min(Comparator.comparingDouble(craftsman -> craftsman.totalEarnings)).orElse(null);
    }

    @Override
    public Collection<ApartmentRenovation> getApartmentsByRenovationCost() {
        return assignments.keySet().stream().sorted(Comparator.comparingDouble(this::calculateRenovationCost).reversed()).collect(Collectors.toList());
    }

    private double calculateRenovationCost(ApartmentRenovation apartment) {
        Craftsman contractor = assignments.get(apartment);
        if (contractor != null) {
            return apartment.workHoursNeeded * contractor.hourlyRate;
        } else {
            return apartment.workHoursNeeded;
        }
    }

    @Override
    public Collection<ApartmentRenovation> getMostUrgentRenovations(int limit) {
        Comparator<ApartmentRenovation> comparator = (e1, e2) -> {
            if (e1.deadline.equals(e2.deadline)) {
                return Double.compare(e1.area, e2.area);
            }
            return e1.deadline.compareTo(e2.deadline);
        };

        return assignments.keySet().stream()
                .sorted(comparator)
                .limit(limit)
                .collect(Collectors.toList());
    }






}