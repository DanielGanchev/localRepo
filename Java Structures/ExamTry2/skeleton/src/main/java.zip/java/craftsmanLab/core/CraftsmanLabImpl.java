package craftsmanLab.core;

import craftsmanLab.models.ApartmentRenovation;
import craftsmanLab.models.Craftsman;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

public class CraftsmanLabImpl implements CraftsmanLab {

    private final List<String> addresses = new ArrayList<>();

    private final Map<ApartmentRenovation, Craftsman> assignments = new LinkedHashMap<>();
    private final Map<Craftsman,List<ApartmentRenovation>> craftsmanAll = new HashMap<>();





    @Override
    public void addApartment(ApartmentRenovation job) {
        if (addresses.contains(job.address)) {
            throw new IllegalArgumentException();
        }

        addresses.add(job.address);
        assignments.put(job, null);
    }

    @Override
    public void addCraftsman(Craftsman craftsman) {
        if (exists(craftsman)) {
            throw new IllegalArgumentException();
        }

        craftsmanAll.put(craftsman,new ArrayList<>());

    }

    @Override
    public boolean exists(ApartmentRenovation job) {
      return assignments.containsKey(job);
    }

    @Override
    public boolean exists(Craftsman craftsman) {
        return craftsmanAll.containsKey(craftsman);
    }



    @Override
    public void removeCraftsman(Craftsman craftsman) {
       if (!exists(craftsman) || assignments.containsValue(craftsman)) {
            throw new IllegalArgumentException();
        }
        craftsmanAll.remove(craftsman);

    }

    @Override
    public Collection<Craftsman> getAllCraftsmen() {
        return craftsmanAll.keySet();
    }



    @Override
    public void assignRenovations() {

        if (!craftsmanAll.isEmpty() || !assignments.isEmpty()) {
          assignments.forEach((apartmentRenovation, craftsman) -> {
                if (craftsman == null) {
                    Craftsman craftsman1 = craftsmanAll.keySet().stream().min(Comparator.comparingDouble(craftsman2 -> craftsman2.totalEarnings)).orElse(null);

                    craftsmanAll.get(craftsman1).add(apartmentRenovation);
                    assignments.put(apartmentRenovation, craftsman1);
                    craftsman1.totalEarnings += apartmentRenovation.workHoursNeeded * craftsman1.hourlyRate;


              }
          });
        }





    }



    @Override
    public Craftsman getContractor(ApartmentRenovation job) {
        Craftsman contractor = assignments.get(job);
        if (contractor == null) {
            throw new IllegalArgumentException();
        }
        return contractor;
    }

    @Override
    public Craftsman getLeastProfitable() {
        if (craftsmanAll.isEmpty()){
            throw new IllegalArgumentException();
        }
        return craftsmanAll.keySet().stream().min(Comparator.comparingDouble(craftsman -> craftsman.totalEarnings)).orElse(null);
    }

    @Override
    public Collection<ApartmentRenovation> getApartmentsByRenovationCost() {
        return assignments.keySet().stream().sorted(Comparator.comparingDouble(this::calculateRenovationCost).reversed()).collect(Collectors.toList());
    }

    private double calculateRenovationCost(ApartmentRenovation apartment) {
        Craftsman contractor = assignments.get(apartment);
        if (contractor != null) {
            return apartment.workHoursNeeded * contractor.hourlyRate;
        } else {
            return apartment.workHoursNeeded;
        }
    }

    @Override
    public Collection<ApartmentRenovation> getMostUrgentRenovations(int limit) {
        Comparator<ApartmentRenovation> comparator = (e1, e2) -> {
            if (e1.deadline.equals(e2.deadline)) {
                return Double.compare(e1.area, e2.area);
            }
            return e1.deadline.compareTo(e2.deadline);
        };

        return assignments.keySet().stream()
                .sorted(comparator)
                .limit(limit)
                .collect(Collectors.toList());
    }






}