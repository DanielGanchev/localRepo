package com.dictionaryapp.model.entity;

public enum LanguageName {

    GERMAN, SPANISH, FRENCH, ITALIAN
}
